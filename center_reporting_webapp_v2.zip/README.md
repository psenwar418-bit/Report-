# Center Reporting PWA v2

A mobile-first, scalable reporting system for Center Incharges with an Admin-controlled Google-Forms-style builder, action requests, dashboards and Supabase backend.

## Recommended free launch
- Frontend: Cloudflare Pages (static PWA)
- Backend: Supabase Free (Auth + Postgres + Storage)
- Charts: Chart.js
- Notifications: start with in-app action inbox + optional PWA push/Telegram; avoid unofficial WhatsApp automation.
- Free URL: `*.pages.dev` (custom domain is optional).

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Supabase Auth, use Email/Password. For simplest field rollout, disable email confirmation only if your organization's policy allows it.
4. Create the first admin account in Auth, then insert/update its profile role to `admin` and status `active` in the database.
5. Copy `public/config.js.example` to `public/config.js` and add the project's URL + public anon key.
6. Deploy `public/` to Cloudflare Pages, or run locally with `npx serve public -l 3000`.

## Important production hardening
- Keep RLS enabled. Never put Supabase service-role key in browser code.
- Create a private `report-media` Storage bucket and add storage policies before enabling real photo uploads.
- Add audit-log triggers for admin changes.
- Add PWA push notifications only after the core workflow is stable.
- For large photo volumes, compress images client-side and set retention rules.
- Back up exports regularly.

## Current prototype status
This v2 is a redesigned production-oriented scaffold. The local UI and data model are substantially improved over the previous JSON-server prototype. Before public launch, finish Supabase Storage policies, admin bootstrap, and notification provider configuration.
