-- Center Reporting v2: Supabase/Postgres schema + RLS.
create extension if not exists pgcrypto;

create table if not exists public.centers(
 id uuid primary key default gen_random_uuid(), name text not null unique, district text not null check(district in ('Barmer','Jaisalmer')), active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade, full_name text not null, mobile text, role text not null default 'incharge' check(role in ('admin','incharge')), center_id uuid references public.centers(id), status text not null default 'pending' check(status in ('pending','active','blocked')), created_at timestamptz not null default now()
);
create table if not exists public.forms(
 id uuid primary key default gen_random_uuid(), title text not null, description text, form_kind text not null default 'daily', active boolean not null default true, target_all boolean not null default true, due_time time, created_by uuid references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.form_targets(form_id uuid references public.forms(id) on delete cascade, center_id uuid references public.centers(id) on delete cascade, primary key(form_id,center_id));
create table if not exists public.questions(
 id uuid primary key default gen_random_uuid(), form_id uuid references public.forms(id) on delete cascade, label text not null, field_type text not null check(field_type in ('text','longtext','number','select','multi','yesno','date','photo','location')), options jsonb not null default '[]'::jsonb, required boolean not null default false, active boolean not null default true, sort_order int not null default 0, help_text text, created_at timestamptz not null default now()
);
create table if not exists public.submissions(
 id uuid primary key default gen_random_uuid(), form_id uuid references public.forms(id) on delete cascade, staff_id uuid references public.profiles(id), center_id uuid references public.centers(id), report_date date not null default current_date, payload jsonb not null default '{}'::jsonb, submitted_at timestamptz not null default now(), unique(form_id,staff_id,report_date)
);
create table if not exists public.actions(
 id uuid primary key default gen_random_uuid(), title text not null, description text, action_type text not null default 'response' check(action_type in ('response','photo','location','photo_location')), due_at timestamptz, active boolean not null default true, created_by uuid references public.profiles(id), created_at timestamptz not null default now()
);
create table if not exists public.action_targets(action_id uuid references public.actions(id) on delete cascade, center_id uuid references public.centers(id) on delete cascade, primary key(action_id,center_id));
create table if not exists public.action_responses(id uuid primary key default gen_random_uuid(), action_id uuid references public.actions(id) on delete cascade, staff_id uuid references public.profiles(id), center_id uuid references public.centers(id), payload jsonb not null default '{}'::jsonb, submitted_at timestamptz not null default now(), unique(action_id,center_id));
create table if not exists public.audit_log(id bigserial primary key, actor_id uuid references public.profiles(id), event text not null, entity text, entity_id uuid, metadata jsonb default '{}'::jsonb, created_at timestamptz not null default now());

insert into public.centers(name,district) values
('Barmer Center 1','Barmer'),('Barmer Center 2','Barmer'),('Barmer Center 3','Barmer'),
('Jaisalmer Center 1','Jaisalmer'),('Jaisalmer Center 2','Jaisalmer'),('Jaisalmer Center 3','Jaisalmer') on conflict(name) do nothing;

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from profiles where id=auth.uid() and role='admin' and status='active'); $$;
create or replace function public.my_center() returns uuid language sql stable security definer set search_path=public as $$ select center_id from profiles where id=auth.uid(); $$;

alter table public.centers enable row level security; alter table public.profiles enable row level security; alter table public.forms enable row level security; alter table public.form_targets enable row level security; alter table public.questions enable row level security; alter table public.submissions enable row level security; alter table public.actions enable row level security; alter table public.action_targets enable row level security; alter table public.action_responses enable row level security; alter table public.audit_log enable row level security;

create policy "centers read" on centers for select using (true);
create policy "admin centers write" on centers for all using (is_admin()) with check (is_admin());
create policy "profile own read" on profiles for select using (id=auth.uid() or is_admin());
create policy "profile own insert" on profiles for insert with check (id=auth.uid() and role='incharge' and status='pending');
create policy "admin profile manage" on profiles for update using(is_admin()) with check(is_admin());
create policy "forms read" on forms for select using(is_admin() or (active=true and (target_all=true or exists(select 1 from form_targets ft where ft.form_id=forms.id and ft.center_id=my_center()))));
create policy "admin forms manage" on forms for all using(is_admin()) with check(is_admin());
create policy "targets read" on form_targets for select using(is_admin() or center_id=my_center());
create policy "admin targets manage" on form_targets for all using(is_admin()) with check(is_admin());
create policy "questions read" on questions for select using(is_admin() or exists(select 1 from forms f where f.id=questions.form_id and f.active=true and (f.target_all=true or exists(select 1 from form_targets ft where ft.form_id=f.id and ft.center_id=my_center()))));
create policy "admin questions manage" on questions for all using(is_admin()) with check(is_admin());
create policy "submissions own/admin read" on submissions for select using(is_admin() or staff_id=auth.uid());
create policy "submissions own insert" on submissions for insert with check(staff_id=auth.uid() and center_id=my_center());
create policy "submissions own update" on submissions for update using(staff_id=auth.uid()) with check(staff_id=auth.uid() and center_id=my_center());
create policy "actions read" on actions for select using(is_admin() or (active=true and exists(select 1 from action_targets at where at.action_id=actions.id and at.center_id=my_center())));
create policy "admin actions manage" on actions for all using(is_admin()) with check(is_admin());
create policy "action targets read" on action_targets for select using(is_admin() or center_id=my_center());
create policy "admin action targets manage" on action_targets for all using(is_admin()) with check(is_admin());
create policy "action responses own/admin" on action_responses for select using(is_admin() or staff_id=auth.uid());
create policy "action responses insert" on action_responses for insert with check(staff_id=auth.uid() and center_id=my_center());
create policy "audit admin read" on audit_log for select using(is_admin());

-- Storage: create a private bucket named report-media in Supabase Dashboard, then add policies:
-- insert: authenticated users, folder path begins with auth.uid(); select: admin or own folder.
